# CS555 Recipe Journal

A small team starter for the recipe journal project. It includes a runnable Flask page, a framework-light recipe service, CSS, a story-to-test planning matrix, and a starter notebook. The current service keeps data in memory; it is intended for prototyping and tests, not persistent storage.

## Get started

Requires Python 3.11 or newer.

```bash
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
flask --app app run --debug
```

Open <http://127.0.0.1:5000>. Run the tests with:

```bash
python -m pytest
```

## Project map

```text
app/                       Flask app and recipe domain service
app/services/recipes.py    In-memory recipe operations
app/templates/             Jinja page templates
app/static/css/styles.css  Shared starter styles
tests/                     Unit and web smoke tests
docs/story-test-matrix.md  Suggested test coverage for US-01–US-40
notebooks/                 Data model exploration notebook
```

## Working agreements

- Create a branch for each story or small group of related stories.
- Keep acceptance criteria visible in the issue or pull request.
- Add or update tests with each behavior change.
- Open a pull request for review; avoid committing directly to the default branch.
- Keep secrets and real user data out of the repository.

## Current limits

This scaffold has no database, authentication, external recipe import, or real user accounts. Pantry, meal planning, shopping-list generation, and other later stories are listed in the test matrix so the team can agree on their behavior before implementing them.
